#!/usr/bin/env python
# coding: utf-8

# # TP d'introduction à NetworkX

# ## I)  Création de graphe

# N.B. : les commandes de la cellule suivante permettent d'afficher tous les résultats d'une cellule, et pas uniquement le dernier

# In[435]:


# affiche tous les résultats d'une cellule, et pas uniquement le dernier
from IPython.core.interactiveshell import InteractiveShell
InteractiveShell.ast_node_interactivity = "all"


# Dans la suite, vous aurez besoin des packages `networkx`, `matplotlib` et `scipy`. Installez-les à l'aide de la commande `pip install *package*` (dans un terminal) si vous ne les avez pas sur votre machine.

# ### I.1- Création d'un graphe simple

# In[436]:


import networkx as nx
import matplotlib.pyplot as plt

graphe_simple = nx.Graph()
graphe_simple.add_edges_from([(1, 2), (1, 3), (2, 3), (2, 4), (2, 5), (3, 4), 
                         (4, 5), (4, 6), (5, 7), (5, 8), (7, 8)])
nx.draw(graphe_simple, with_labels=True, font_weight='bold')  


# ### I.2- Dessiner le graphe  par plot

# In[454]:


# Gestion de l'affichage par plot
plt.figure(figsize =(9, 12))
plt.subplot(211)
nx.draw_networkx(graphe_simple)


# ### I. 3 - Création d'un graphe orienté (qui est aussi biparti)

# In[455]:


graphe_oriente = nx.DiGraph()
graphe_oriente.add_edge(1, 2)
graphe_oriente.add_edges_from([(1, 2),(1,3)])
nx.draw(graphe_oriente, with_labels=True)


# On ajoute d'autres éléments à ce graphe

# In[456]:


# On ajoute d'autres éléments
graphe_oriente.add_node(5)
graphe_oriente.add_nodes_from([3,4]) # 3 y est déjà
graphe_oriente.add_edge(4, 5) # Cet ajout transforme graphe_oriente en non connexe
nx.draw(graphe_oriente, with_labels=True)


# Remarquez que ce graaphe reste non connexe

# ### I. 4 - suppression des noeuds dans un graphe

# D'abord, créons un graphe 

# In[457]:


path_graphe = nx.path_graph(5)  # ou DiGraph, MultiGraph, MultiDiGraph, etc
list(path_graphe.edges)
nx.draw(path_graphe, with_labels=True)


# Puis on enlève des noeuds

# In[458]:


path_graphe.remove_node(1)
list(path_graphe.edges)


# Puis on enlève des arêtes

# In[459]:


# Enlever l'aroete (2,3)
e = (2,3)
path_graphe.remove_edge(*e)

# Ce qui reste
list(path_graphe.edges)


# ### I.5- Un sous graphe de graphe_simple

# In[460]:


sous_graphe = graphe_simple.subgraph([1, 2, 3, 4])
# [1, 2, 3, 4] est un sous ensemble des noeuds de graphe_simple
  
plt.subplot(212)
nx.draw_networkx(sous_graphe)


# ## II) Exercices 1

# networkX est capable de produire un graphe de Petersen (sous forme de shell=escargot)

# In[461]:


graphe_petersen = nx.petersen_graph()
#nx.draw_networkx(graphe_petersen)

pos = nx.shell_layout(graphe_petersen, nlist=[range(1,6), range(6,11)])

nx.draw_shell(graphe_petersen, nlist=[range(5,10), range(5)],with_labels=True)


# #### II.1-  Créez le même graphe de Petersen en donnant **explicitement** la liste de ses arêtes

# In[462]:


graphe_simple2 = nx.Graph()
graphe_simple2.add_edges_from([(1,3), (1,4), (1,6), (2,4), (2,5), (2,7), (3,5), (3,8), (4, 9), (5, 10), (6,7), (6,10), (7,8), (8,9), (9, 10)])


# #### II.2-   Affichez le graphe créé, en indiquant les numéros de sommets en gras

# In[463]:


nx.draw(graphe_simple2, with_labels=True, font_weight='bold')


# Par défaut, les sommets sont disposés de manière **aléatoire**, ce qui ne facilite pas la lecture des graphes ayant une structure régulière, comme le graphe de **Petersen**. 
# 
# Cherchez dans la documentation de NetworkX une autre fonction permettant d'afficher ce graphe sous une forme plus "classique".

# #### II.3-   Affichez le graphe de manière "symétrique"

# In[464]:


nx.draw_shell(graphe_simple2, nlist=[range(1,6), range(6,11)], with_labels=True, font_weight='bold')


# ## III) Quelques fonctions / propriétés 

# ## III.1 - Quelques fonctions utiles
# Les méthodes suivantes permettent d’accéder aux attributs du graphe et fournissent les primitives essentielles :
# 
# - g.degree() : degrés des sommets du graphe g
# - g.number_of_nodes() : nombre de sommets du graphe g
# - g.number_of_edges() : nombre d’arcs du graphe g
# - g.predecessors(i) : liste des prédecesseurs du sommet i
# - g.successors(i) : liste des successeurs du sommet i
# - g.neighbors(i) : liste des voisins du sommet i
#     On dispose aussi des indicateurs et outils suivants (liste non exhaustive) :
# 
# - density(g) : densité du graphe g (voir ci-dessous)
# - diameter(g) : diamètre du graphe g
# - shortest_path(g) : plus courts chemins entre tous les couples de sommets de g
# - pagerank(g) : calcul du pagerank 

# ## III.2 - Et quelques définitions

# - **densité** : la **densité** d'un graphe est  le rapport entre le nombre d'arêtes (ou d'arcs) divisé par le nombre d'arêtes (ou d'arcs) possibles.
# 
# - Pour un graphe $G=(V, E)$ avec $|V|$ noeuds (sommets) et $|E|$ arêtes, la densité permet de savoir si $G$ possède beaucoup d'arêtes ou non. 
# 
# - Dans le cas d'un graphe non orienté simple ${\displaystyle G=(V,E)}$, la densité est le rapport ${\displaystyle D={\frac {2\ |E|}{|V|\cdot (|V|-1)}}}$
# 
# 
# - Un **graphe  dense** est un graphe dans lequel le nombre d'arêtes (ou d'arcs) est proche du nombre maximal ($V^2$). 
# Un **graphe creux** (_sparse_) a au contraire peu d'arêtes. 
# - La densité 0 correspond au graphe où tous les sommets sont isolés (pas d'arête entre les noeuds).
# 
# - Un **graphe complet** : la densité 1 correspond à un  graphe dit **complet**. 
# Un graphe complet est un graphe simple dont tous les sommets sont adjacents deux à deux. 
# - Un graphe orienté est _complet_ si chaque paire de sommets est reliée par exactement deux arcs (un dans chaque sens).
# 
#     Exemple d'un graphe complet :
# 
# ![graphe complet](Fig-Graphe-Complet2.png)
# 
# 
# Pour un graphe **complet** $G=(V, E)$ avec $|V|$ sommets, le nombre d'arêtes est donné par
# $\hspace{3cm} {\displaystyle |E| = \sum _{{i=1}}^{{|V|}}\left(|V|-i\right)=\sum _{{i=1}}^{{|V|-1}}i={\frac  {|V|\ (|V|-1)}{2}}}$
# 
# 
# - On obtient le même résultat  en considérant le nombre d’arêtes $|E|$ comme le nombre de couples distincts que l’on peut former avec ${\displaystyle |V|}$ noeuds, soit ${\displaystyle {\binom  {|V|}{2}}}$ arêtes, ce qui vaut bien ${\displaystyle {\dfrac {|V| \ (|V|-1)}{2}}}$
# 
# 
# - **Nombre chromatique** $k$ d'un graphe est le nombre **chromatique** ($k$= nombre de couleurs nécessaires pour colorer les noeuds tel que 2 noeuds adjacents n'ont pas la même couleur).
# - Pour un graphe _complet_, le nombre chromatique $k$ est égal au nombre de noeuds  $|V|$.
# 
# - Un **graphe régulier** est un graphe où tous les sommets ont le même nombre de voisins, c'est-à-dire le même **degré** ou **valence**. Un graphe régulier dont les sommets sont de degré $k$ est appelé un graphe **k-régulier** ou graphe régulier de degré $k$.
# 
# ## III.3 - Matrice d'adjacence
# - La matrice sysmétrique ($noeuds \times noeuds$).
# 
# ## III.4 - Matrice d'incidence
# 
# C'est une matrice (0,1) avec une ligne par noeud et une colonne par arête.
# - On met (v,e)=1 ssi le noeud v est  incident suivant edge e 
# - N.B. : parfois, la matrice d'incidence est présentée comme la transposé de le définition ci-dessus avec une colonne pour chaque noeud et une ligne par edge.
# - Il y a un lien entre la matrice d'incidence $C$ et la matrice d'adjacence $L$ :
# 
# $\hspace{2cm} {\displaystyle L=C^t C-2I}$,  où  $I$ est une matrice d'identité .
# ## III.5 - Exemples des matrices d'incidence de 3 graphes :
# 
# ![graphe ?](Image.png)

# In[465]:


# Une autre façon d'insérer une image
#from IPython.display import Image
#from IPython.core.display import HTML 
#Image(filename = "./Fig-Graphe-Complet.png", width=100, height=100)


# ## IV) Exercice 2 :
# Pour les questions qui suivent, donnez la réponse en utilisant les fonctions de **NetworkX**

# On rappelle le graphe construit ci-dessus :

# In[466]:


nx.draw_shell(graphe_simple2, nlist=[range(1,6), range(6,11)], with_labels=True, font_weight='bold')


# Le "contenu" du même graphe décrit sous forme de dict of dict :
# - Pour chaque noeud, on a les voisins donnés sous forme de dict.
# - Par exemple, 
#     1: {3: {}, 4: {}, 6: {}}
# nous dit que le noeud 1 a pour voisins les noeuds  [3,4,6], ces voisins sont décrits à leur tour dans le dico principal.

# In[467]:


nx.to_dict_of_dicts(graphe_simple2)


# ## IV.1 - Ce graphe est-il orienté ou non orienté ?

# In[468]:


graphe_simple2.is_directed()


# ## IV.2 - Quels sont ses sommets et ses arêtes ?

# In[469]:


graphe_simple2.nodes
graphe_simple2.edges


# ## IV.3 - Quels sont les voisins du sommet 2 ? Quel est le degré du sommet 10 ?

# In[470]:


list(graphe_simple2.neighbors(2))
graphe_simple2.degree(10)


# ## IV.4 - Ce graphe est-il régulier ?
# 
# - Rappel : dans un graphe régulier, tous les sommets ont le même nombre de voisins (le même **degré** ou la même **valence**). Un graphe régulier dont les sommets sont de degré $k$ est appelé un graphe **k-régulier** ou graphe régulier de degré $k$.

# In[472]:


d = list(graphe_simple2.degree)
d # ou print(d) si l'option InteractiveShell.ast_node_interactivity = "all" n'est pas donnée.

# Le dégré du 1er noeud (noeud 1)
"degré du noeud 1" , d[0][1]

# Vérification (par soi) de la régularité : est-ce que tous les noeuds ont le même degré
"test manuel", all(elem[1] == d[0][1] for elem in d)

# Demandez à networkX !
"test par networkX", nx.is_regular(graphe_simple2)


# ## IV.5 - Donnez sa matrice d’incidence et sa matrice d’adjacence

# In[381]:


# Sans passer par "todense", les affichages sont inéfficaces !
nx.incidence_matrix(graphe_simple2).todense()
nx.adjacency_matrix(graphe_simple2).todense()


# ## IV.6- Quel est le sous-graphe induit par les sommets {6, 3, 7, 8, 1, 5} ?

# In[473]:


subG = graphe_simple2.subgraph([6, 3, 7, 8, 1, 5])
nx.draw(subG, with_labels=True, font_weight='bold')


# ## V)  Graphe de Petersen et le circuit Hamiltonien 

# **Reprenons l'exemple de graph de Petersen ci-dessus**

# In[474]:


G = nx.petersen_graph()
#nx.draw_networkx(G)

pos = nx.shell_layout(G, nlist=[range(1,6), range(6,11)])

nx.draw_shell(G, nlist=[range(5,10), range(5)],with_labels=True)


# ## V.1- Exercice : Hemilton
# En revenant à notre graphe G, mettez en évidence (avec des arêtes rouges) un chemin hamiltonien (calculé à la main) sur le graphe de Petersen

# In[477]:


ham_path = [(10,6), (6,7), (7,8), (8,9), (9,4), (4,1), (1,3), (3,5), (5,2)]

# ancienne version de networkX : nx.draw_networkx_edges(G,pos,edgelist=list(set(G.edges) - set(ham_path)),edge_color='black',width=1)
nx.draw_networkx_edges(G,pos,edgelist=ham_path,edge_color='r',width=3)
plt.axis('equal')
#plt.show()


# Et avec le graphe d'origine :

# In[478]:


G = nx.petersen_graph()


pos = nx.shell_layout(G, nlist=[range(1,6), range(6,11)])

nx.draw_shell(G, nlist=[range(5,10), range(5)],with_labels=True)
ham_path = [(10,6), (6,7), (7,8), (8,9), (9,4), (4,1), (1,3), (3,5), (5,2)]

# ancienne version de networkX : nx.draw_networkx_edges(G,pos,edgelist=list(set(G.edges) - set(ham_path)),edge_color='black',width=1)
nx.draw_networkx_edges(G,pos,edgelist=ham_path,edge_color='r',width=3)
plt.axis('equal')
#plt.show()


# ## VI) Exercice 3
# ### a) 
# Ecrivez une fonction `parcoursLargeur` qui prend en paramètres un graphe `G` et un sommet `s`, et qui retourne l'ordre de parcours en largeur de `G` quand on part de `s` (on supposera que `G` est connexe, et qu'on traite les sommets par ordre croissant)
# 

# In[479]:


# Ordre croissant
def parcoursLargeur1(G, s):
    file = [s]
    sortie = []
 
    # On effectue le parcours BFS
    while file:
        u = file.pop(0)
        sortie.append(u)
        voisins=[v for v in list(G.neighbors(u)) if v not in file and v not in sortie]
        # Parcours dans l'ordre croissant
        file.extend(sorted(voisins))
    
    return sortie

graphe_simple = nx.Graph()
graphe_simple.add_nodes_from([1, 2])
while not nx.is_connected(graphe_simple):
    graphe_simple = nx.gnm_random_graph(10, 15)
nx.draw(graphe_simple, with_labels=True, font_weight='bold')

print(parcoursLargeur1(graphe_simple, list(graphe_simple.nodes())[0]))


# ####  Une autre solution : la même chose d'une autre manière 

# In[480]:


def parcoursLargeur2(G):
    sommets = list(G.nodes)
    sortie = []

    # On effectue le parcours BFS
    while sommets:
        file = [sommets[0]]
        while file:
            u = file.pop(0)
            sortie.append(u)
            sommets.remove(u)
            voisins=[v for v in list(G.neighbors(u)) if v not in file and v not in sortie]
            # Parcours dans l'ordre croissant
            file.extend(sorted(voisins))
    
    return sortie

nx.draw(graphe_simple, with_labels=True, font_weight='bold')
print(parcoursLargeur2(graphe_simple))


# #### La même chose d'une autre manière (avec un autre graphe)

# In[481]:


def parcoursLargeur3(G):
    sommets = list(G.nodes)
    sortie = []
    
    # On effectue le parcours BFS
    while sommets:
        file = [sommets[0]]
        compconn = []
        while file:
            u = file.pop(0)
            compconn.append(u)
            sommets.remove(u)
            file.extend([v for v in list(G.neighbors(u)) if v not in file and v not in compconn])
                    
        sortie.append(compconn)
                
    return sortie

nx.draw(graphe_simple, with_labels=True, font_weight='bold')
print(parcoursLargeur3(graphe_simple))


# ### b) 
# Modifiez la fonction précédente pour qu'elle démarre le parcours par le plus petit sommet, et retourne l'ordre de parcours en largeur même si `G` n'est pas connexe

# On va créer à la main un graphe non connexe (simplement, on ne relie pas certain couples de noeud).

# In[483]:


graphe_simple3 = nx.Graph()
graphe_simple3.add_edges_from([(1, 2), (1, 3), (2, 3), (2, 4),  (3, 4), 
                          (4, 6), (5, 7), (5, 8), (7, 8)])
nx.draw(graphe_simple3, with_labels=True, font_weight='bold') 


# Le parcours en largeur

# In[484]:


print(parcoursLargeur1(graphe_simple3, 1))  


# ### Une autre solution : sur graphe non connexe
# On va utiliser la fonction nx.random_clustered_graph() de networkX pour créer notre graphe.

# In[486]:


# On crée un graphb non connexe (voir la cellule suivante pour la doc)
deg = [(1, 0), (1, 0), (1, 0), (2, 0), (1, 0), (2, 1), (0, 1), (0, 1)]
graphe_random_cluster = nx.random_clustered_graph(deg)
nx.draw(graphe_random_cluster, with_labels=True, font_weight='bold')

print(parcoursLargeur1(graphe_random_cluster, list(graphe_random_cluster.nodes())[0])) # list(graphe_random_cluster.nodes())[0] = Le noeud 0


# #### Extrait de la documentation  sur le graphe généré (la doc networkx):
# **random_clustered_graph(joint_degree_sequence, create_using=None, seed=None)**
# 
# Generate a random graph with the given joint independent edge degree and triangle degree sequence.
# 
# This uses a configuration model-like approach to generate a random graph (with parallel edges and self-loops) by randomly assigning edges to match the given joint degree sequence.
# 
# The joint degree sequence is a list of pairs of integers of the form . According to this list, vertex  is a member of  triangles and has  other edges. The number  is the triangle degree of  and the number  is the independent edge degree.
# 
# Parameters
# joint_degree_sequence : list of integer pairs
# Each list entry corresponds to the independent edge degree and triangle degree of a node.
# 
# create_using : NetworkX graph constructor, optional (default MultiGraph)
# Graph type to create. If graph instance, then cleared before populated.
# 
# seed : integer, random_state, or None (default)
# Indicator of random number generation state. See Randomness.
# 
# Returns : a MultiGraph
# 
# A graph with the specified degree sequence. Nodes are labeled starting at 0 with an index corresponding to the position in deg_sequence.

# ## c) 
# Utilisez la fonction précédente pour écrire une fonction `compConnexesL` qui prend en paramètres un graphe `G`, et qui retourne la liste des composantes connexes de G (sous la forme d'une liste de listes)

# ### Solution  (indication) : 
# - Créer L = la liste des noeuds
# - Liste_composantes_connexes = vide
# - Répéter
#     - Lancez un parcours en largeur avec le 1er noeud (le plus petit) de L et récupérer la liste L1 des noeuds empruntés.
#         Pour un graphe non connexe, L1 est différente (incluse dans) L.
#     - L1 sera un des composantes connexe : ajouter L1 à Liste_composantes_connexes
#     - Choisir un noeud N dans L2 = L - L1 (la différence entre L et L1)
#     - Si L2 != vide alors L=L2
# - Jussqu'à L=vide
# - Liste_composantes_connexes est la solution

# ### Solutions avec networkX : recherche de composantes connexes

# In[487]:


compos_connexes_graphe_simple=nx.connected_components(graphe_simple)
resultat_graphe_simple=list(compos_connexes_graphe_simple) # On save sinon le générateur oublie les valeurs ?
resultat_graphe_simple

# La taille des composantes
[len(c) for c in sorted(resultat_graphe_simple, key=len, reverse=True)]


# #### Même chose avec un autre graphe 'graphe_random_cluster'

# In[490]:


list(nx.connected_components(graphe_random_cluster))


# #### Récupérer les composantes et donner leur taille

# In[493]:


compos_connexes=list(nx.connected_components(graphe_random_cluster))
compos_connexes

# La taille des composantes
[len(c) for c in sorted(compos_connexes, key=len, reverse=True)]


# ## VII) Exercice 4
# ### a) 
# Ecrivez une fonction `parcoursProfondeur` qui prend en paramètres un graphe `G` et un sommet `s`, et qui retourne l'ordre de parcours en profondeur de `G` quand on part de `s` (on supposera que `G` est connexe, et qu'on traite les sommets par ordre croissant)
# 
# ### b)  
# Modifiez la fonction précédente pour qu'elle démarre le parcours par le plus petit sommet, et retourne l'ordre de parcours en largeur même si `G` n'est pas connexe
# 
# ### c)  
# Utilisez la fonction précédente pour écrire une fonction `compConnexesP` qui prend en paramètres un graphe `G`, et qui retourne la liste des composantes connexes de G (sous la forme d'une liste de listes)
# 

# In[495]:


# On marque les sommets au fur et à mesure de leur insertion dans la pile
def parcoursProfondeur1(G, s):
    pile = [s]
    sortie = [s]
 
    # On effectue le parcours DFS
    while pile:
        sommet = pile[-1] # on considère toujours le dernier élément de la pile
        voisins = [v for v in list(G.neighbors(sommet)) if v not in pile and v not in sortie]
        voisins.sort()
        if voisins == []:
            pile.pop()
        else:
            pile.append(voisins[0])
            sortie.append(voisins[0])
    
    return sortie
    

nx.draw(graphe_simple, with_labels=True, font_weight='bold')
print(parcoursProfondeur1(graphe_simple, list(graphe_simple.nodes())[0]))


# ### a-bis : Une variante de l'algorithme
# ** N.B. ** les conditions d'appel ne sont pas les mêmes (d'où la différence des résultats)

# In[499]:


# On marque les sommets au fur et à mesure de leur insertion dans la pile
def parcoursProfondeur2(G):
    sommets = list(G.nodes)
    sortie = []

    # On effectue le parcours DFS
    while sommets:
        pile = [sommets[0]]
        sortie.append(sommets[0])
        sommets.pop(0)
        while pile:
            sommet = pile[-1] # on considère toujours le dernier élément de la pile
            voisins = [v for v in list(G.neighbors(sommet)) if v not in pile and v not in sortie]
            voisins.sort()
            if voisins == []:
                pile.pop()
            else:
                pile.append(voisins[0])
                sortie.append(voisins[0])
                sommets.remove(voisins[0])
    
    return sortie
    
nx.draw(graphe_simple, with_labels=True, font_weight='bold')
print(parcoursProfondeur2(graphe_simple))


# ### a-ter : Une variante de l'algorithme
# **N.B.** les conditions d'appel sont les mêmes ici que dans le cas a-bis
# 

# In[500]:


# On marque les sommets au fur et à mesure de leur insertion dans la pile
def parcoursProfondeur3(G):
    sommets = list(G.nodes)
    sortie = []

    # On effectue le parcours DFS
    while sommets:
        pile = [sommets[0]]
        compconn = [sommets[0]]
        sommets.pop(0)
        while pile:
            sommet = pile[-1] # on considère toujours le dernier élément de la pile
            voisins = [v for v in list(G.neighbors(sommet)) if v not in pile and v not in compconn]
            voisins.sort()
            if voisins == []:
                pile.pop()
            else:
                pile.append(voisins[0])
                compconn.append(voisins[0])
                sommets.remove(voisins[0])
        
        sortie.append(compconn)
    
    return sortie
    

nx.draw(graphe_simple, with_labels=True, font_weight='bold')
print(parcoursProfondeur3(graphe_simple))


# ### a-quater)  Demandons à networkX de nous réaliser les mêmes tâches

# In[501]:


### Rappel du graphe (connexe) graphe_simple
nx.draw(graphe_simple, with_labels=True, font_weight='bold')


# ### Demnadez le même parcours (BFS) à newtworkX

# In[502]:


edges = nx.bfs_edges(graphe_simple, 0)
list(edges)


# #### Pour aller plus loin, on définit **l'arbre** de BFS :

# In[503]:


# Et l'arbre BFS

tree = nx.bfs_tree(graphe_simple, 0) 
print(list(tree))
list(tree.edges())
nx.draw_networkx(tree)


# #### Succs et pred dans ce parcours

# In[504]:


successors = nx.bfs_successors(graphe_simple,0) 
print(list(successors))

predecessors = nx.bfs_predecessors(graphe_simple,0) 
print(list(predecessors))


# ## VIII) Exercice 5
# ### a) 
# Ecrivez une fonction `estBiparti` qui prend en paramètre un graphe `G` et retourne `True` si `G` est biparti et `False` sinon
# 
# ### b) 
# Modifiez la fonction pour qu'elle retourne un *certificat* de la réponse, c'est-à-dire :
# - la bipartition de l'ensemble des sommets si `G` est biparti
# - un cycle impair qui prouve que `G` n'est pas biparti, sinon

# In[513]:


def findCycle(tabParents, v, w):
    cycle = []
    stack = []
    x = v
    y = w
    while x != y:
        stack.append(x)
        cycle.append(y)
        x = tabParents[x]
        y = tabParents[y]

    stack.append(x)
    while stack:
        cycle.append(stack.pop(-1))
    cycle.append(w)
    return cycle

def estBiparti(G): 
    # On crée un tableau de couleurs pour tous les sommets
    # -1 si le sommet n'est pas exploré, sinon couleur 0 ou 1
    tabCouleurs = [-1] * G.number_of_nodes()    
    parent = [-1] * G.number_of_nodes()

    # On colorie le premier sommet
    sommetInitial = list(G.nodes())[0]
    tabCouleurs[sommetInitial] = 1
    
    # On utilise une file d'attente pour gérer l'ordre BFS
    file = []
    file.append(sommetInitial)
 
    # On effectue un parcours BFS
    while file:
        u = file.pop(0)

        # retourne False si on détecte une boucle (cycle de taille 1)
        if u in list(G.neighbors(u)):
            return False

        # on parcourt la liste des voisins de u
        for v in list(G.neighbors(u)):
            # premier cas : v n'a pas encore été visité
            if tabCouleurs[v] == -1:
                # on affecte la couleur alternée de u
                tabCouleurs[v] = 1 - tabCouleurs[u]
                file.append(v)
                parent[v] = u
            
            # Deuxième cas : si v a déjà été visité, et a la même couleur que u
            # => on a un cycle impair
            elif tabCouleurs[v] == tabCouleurs[u]:
                print(findCycle(parent, u, v))
                return False, u, v, tabCouleurs, parent

            # si v a été visité et n'a pas la même couleur que u, on n'a rien à faire

    # Si on arrive ici, tous les sommets ont été coloriés de manière alternée, donc G est biparti
    return True, [[i for i, x in enumerate(tabCouleurs) if x == 0], [i for i, x in enumerate(tabCouleurs) if x == 1]]


# #### Test avec un graphe cyclique

# In[514]:


# On génère un graphe cyclique
G5 = nx.generators.classic.cycle_graph(5)
nx.draw(G5, with_labels=True, font_weight='bold')
print(estBiparti(G5))


# #### Un autre test avec  un graphe biparti aléatoire généré

# In[515]:


biparti_random = nx.algorithms.bipartite.generators.random_graph(4,5,0.6)
nx.draw(biparti_random, with_labels=True, font_weight='bold')
print(estBiparti(biparti_random))


# #### N.B. :  L'algorithme ci-dessus fonctionne (seulement) avec un graphe connexe.

# #### Sur le graphe biparti généré, on peut récupérer les 2 ensembles de noeuds du graphe **biparti_random** ci-dessus

# On peut récupérer les 2 ensembles de noeuds avec l'attribut **bipartite**  des noeuds :

# In[521]:


ensemble_de_noeuds1 = {n for n, d in biparti_random.nodes(data=True) if d["bipartite"] == 0}
ensemble_de_noeuds2 = set(biparti_random) - ensemble_de_noeuds1
ensemble_de_noeuds1
ensemble_de_noeuds2


# Parfois, on doit récupérer les noeuds appartenant à chaque ensemble de noeuds pour pouvoir l'utiliser en argument de certains algorithmes qui l'exige :
#     ici on récupère la densité du graphe biparti_random ci-dessus.

# In[523]:


round(nx.algorithms.bipartite.density(biparti_random, ensemble_de_noeuds2), 2)

# Projection sur un ensemble de noeuds
biparti_random_projete = nx.algorithms.bipartite.projected_graph(biparti_random, ensemble_de_noeuds1)
nx.draw(biparti_random_projete, with_labels=True)


# ### a-bis)  Un autre test de la fonction **estBiparti** sur  un graphe   **orienté**

# In[534]:


### On reprend le grapge graphe_oriente du début de ce document
nx.draw(graphe_oriente, with_labels=True, font_weight='bold')


# #### On va ajouter une arête pour rendre graphe_oriente connexe (au cas où)

# In[536]:


graphe_oriente.add_edge(1, 5) # Cet ajout transforme graphe_oriente en non connexe
nx.draw(graphe_oriente, with_labels=True)


# In[537]:


# Un autre test de biparti

digraphe1_ = nx.algorithms.bipartite.generators.random_graph(4,5,0.6)
print(estBiparti(digraphe1_))
nx.draw(digraphe1_, with_labels=True, font_weight='bold')


# #### Attention
# nx.is_connected(graphe_oriente) ne fonctionne pas sur un graphe orienté (Digraph)

# In[538]:


#nx.is_connected(graphe_oriente) #fait erreur : NetworkXNotImplemented: not implemented for directed type


# #### De même, pour un graphe non connexe, récupérer les biparti n'a pas de sens

# In[539]:


# Fait erreur sur un  Disconnected graph: Ambiguous solution for bipartite sets.
# CE n'est pas le cas ici à moins d'enlever une arête 
X1, Y1 = nx.bipartite.sets(graphe_oriente)
list(X1)
list(Y1)


# # IX) Exercice 6:

# - a) Créer un graphe quelconque, par exemple watts par 
# 
#             votre_graphe=nx.watts_strogatz_graph(15 ,4 ,20) )
#     
#     Dessiner ce graphe
#     
#     Demander des infos par 
#     
#             print(nx.info(votre_graphe))
# - b) Chercher dans la documentation comment appliquer l'algorithme de Dijkstra à ce graphe
# 
#     **Indications** : 
#     - Appliquer Dijkstra entre 2 noeuds  par :
#         nx.dijkstra_path(votre_graphe, 0, 10)
#     - Obtenez la longueur de ce chemin par :
#         nx.dijkstra_path_length(votre_graphe, 0, 10)

# ### a)

# In[543]:


votre_graphe = nx.watts_strogatz_graph(15 ,4 ,20) 
nx.draw_networkx(votre_graphe)
print(nx.info(votre_graphe))


# - C) Quel est l'effet de ceci sur votre_graphe ? (chercher à comprendre ce que fait cette fonction).

# In[545]:


import itertools
print(list(itertools.combinations(votre_graphe.nodes(), 3))[:10])
#print(list(itertools.combinations(votre_graphe.nodes(), 3)))


# # X) Exercice 7:

# Coder l'algorithme **A_star** à ce même graphe 

# <font color='red'> Cet exercice est un bonus et/ou peut remplacer un compte rendu.</font>

# In[ ]:




